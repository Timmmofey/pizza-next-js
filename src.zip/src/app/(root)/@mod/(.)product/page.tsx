
export default async function ProductModalPage({params: {id}} : {params: {id: string}}) {

    return (
        <h1>12345</h1>
    )
}